<?php $__env->startComponent('mail::message'); ?>
# A new Translation Order has been placed!

A new translation order with work number <span style="font-weight: bold"><?php echo e($order->worknumber); ?></span> has been placed
 by <span style="font-weight: bold"><?php echo e($user->name); ?></span> (<?php echo e($user->email); ?>). <br>

 Respond to it ASAP.

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\translation\resources\views/emails/adminOrderCreated.blade.php ENDPATH**/ ?>