<?php $__env->startComponent('mail::message'); ?>
# Hello!

Order Worknumber: <span style="font-weight: bold"><?php echo e($order->worknumber); ?></span> <br>
Current Language: <span style="font-weight: bold"><?php echo e($order->language1); ?></span><br>
Language to be translated in: <span style="font-weight: bold"><?php echo e($order->language2); ?></span><br>

Kindly find the documents to be proofread attached below.


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\translation\resources\views/emails/orderToProofReader.blade.php ENDPATH**/ ?>