

<?php $__env->startSection('content'); ?>
<div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-4 mb-4">   
  
</div>
<!-- BEGIN: Data List -->
<div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
    <table id="myTable" class="table table-striped" style="width:100%">                        
        <thead>
              <tr>
                  <th class="whitespace-nowrap">#</th>
                  <th class="whitespace-nowrap">Work Number</th>
                  <th class="whitespace-nowrap">Current Language</th>
                  <th class="whitespace-nowrap">Translated Language</th>
                  <th class="whitespace-nowrap">Payment Status</th>
                  <th class="whitespace-nowrap">Actions</th>

              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
                  <td class="whitespace-nowrap"><?php echo e($order->id); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->worknumber); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->language1); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->language2); ?></td>
                  <?php if($order->paymentStatus == 1): ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-success w-24 mr-1 mb-2">Paid</button></td>
                  <?php else: ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-pending w-24 mr-1 mb-2">Pending</button></td>
                  <?php endif; ?>
                  
                  
                  <td class="whitespace-nowrap">
                    <div class="flex  items-center">
                        <a href="javascript:;" data-trigger="click" title="<?php echo e($order->orderStatus); ?>" class="tooltip btn btn-primary mr-1 mb-2">Show Progress</a>

                        <a href="<?php echo e(route('downloadFiles',$order->id)); ?>" class="btn btn-warning mr-1 mb-2"> <i data-lucide="download" class="w-5 h-5"></i> </a>
                        
                        <a href="<?php echo e(route('mailToTranslator',$order->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="calendar" class="w-5 h-5 mr-2"></i> Mail to Translator </a>
                        <form action="<?php echo e(route('destroy', $order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div> <button type="submit" class="btn btn-danger mb-2"><i data-lucide="trash" class="w-4 h-4"></i></button> </div> <!-- END: Modal Toggle -->
                        </form>

                    </div>  
                </td>


              </tr>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


    
</div>
<!-- END: Data List -->
<!-- END: Pagination -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translation\resources\views/admin/paidOrders.blade.php ENDPATH**/ ?>