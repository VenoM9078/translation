

<?php $__env->startSection('content'); ?>

<div class="alert alert-primary show flex items-center mb-4" role="alert"> <i data-lucide="alert-circle" class="w-6 h-6 mr-2"></i> Documents to be translated are automatically attached to this email! </div>

<div class="intro-y box">

    <div id="vertical-form" class="p-5">
        <div class="preview">
            <div>
              <form action="<?php echo e(route('sendDocumentsToTranslator')); ?>" accept-charset="utf-8" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="intro-x mt-4">
                    <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                    <input type="email" name="translator_email" class="intro-x login__input form-control py-3 px-4 block" required placeholder="Enter Translator's Email">
                    <input type="text" name="email_title" class="intro-x login__input form-control py-3 px-4 block mt-4" required placeholder="Email Title">
                    <input type="text" name="email_body" class="intro-x login__input form-control py-3 px-4 block mt-4" required placeholder="Message...">
                                                
                </div>
              
              <button type="submit" name="submit" class="btn btn-primary mt-5">Send Email</button>
            </form>
            </div>
        </div>
       
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translation\resources\views/admin/mailToTranslator.blade.php ENDPATH**/ ?>