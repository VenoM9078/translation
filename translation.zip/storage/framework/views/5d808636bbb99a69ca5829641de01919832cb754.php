

<?php $__env->startSection('content'); ?>
<div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-4 mb-4">   
  
</div>
<div class="intro-y flex items-center h-10 mb-5 mt-2">
    <h2 class="text-lg font-medium truncate ml-2 mr-5">
        Completed Orders
    </h2>
</div>
<hr style="margin-bottom: 30px;">
<!-- BEGIN: Data List -->
<div class="intro-y box">
    <div id="vertical-form" class="p-5">
        <div class="preview">
            <div>
              <div class="overflow-x-auto">
                    <table id="myTable" class="table table-striped" style="width:100%">                                              
        <thead>
              <tr>
                  <th class="whitespace-nowrap">Work Number</th>
                  <th class="whitespace-nowrap">Customer Email</th>
                  <th class="whitespace-nowrap">Current Language</th>
                  <th class="whitespace-nowrap">Translated Language</th>
                  <th class="whitespace-nowrap">Order Status</th>
                  <th class="whitespace-nowrap">Actions</th>

              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
                  <td class="whitespace-nowrap"><?php echo e($order->worknumber); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->user->email); ?></td>

                  <td class="whitespace-nowrap"><?php echo e($order->language1); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->language2); ?></td>
                  <?php if($order->completed == 1): ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-success w-24 mr-1 mb-2">Completed</button></td>
                  <?php else: ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-pending w-24 mr-1 mb-2">Incomplete</button></td>
                  <?php endif; ?>
                  
                  
                  
                  <td class="whitespace-nowrap">
                    <div class="flex  items-center">
                        <a href="<?php echo e(route('downloadTranslatedFiles',$order->id)); ?>" class="btn btn-warning mr-1 mb-2"> <i data-lucide="download" class="w-5 h-5 mr-2"> </i>Download Translated Files </a>
                    </div>  
                </td>


              </tr>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


    </div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translation\resources\views/admin/completedOrders.blade.php ENDPATH**/ ?>