<?php $__env->startComponent('mail::message'); ?>
# Your payment has been approved!

Hello Customer!<br>

We hereby inform you that our team has approved your payment and your Translation Order is well under way!<br>

To track its progress - visit your Dashboard.<br>

<?php $__env->startComponent('mail::button', ['url' => route('myorders')]); ?>
View Dashboard
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\translation\resources\views/emails/paymentApproved.blade.php ENDPATH**/ ?>