<?php $__env->startComponent('mail::message'); ?>
# Hello <?php echo e($user->name); ?>


We have sent you a Payment Invoice for the "<?php echo e($order->language1); ?> to <?php echo e($order->language2); ?>" translation order. <br>

The worknumber of your order is <span style="font-weight: bold;"><?php echo e($order->worknumber); ?></span> and amount to be paid is <span style="font-weight: bold;"><?php echo e($invoice->amount); ?> USD</span>.

Kindly proceed to your User Dashboard (or click the button below) to view invoice & pay the translation fee.

<?php $__env->startComponent('mail::button', ['url' => route('myorders')]); ?>
View Pending Orders
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\translation\resources\views/emails/invoiceSent.blade.php ENDPATH**/ ?>