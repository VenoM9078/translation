

<?php $__env->startSection('content'); ?>
<div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-4 mb-4">
    <a href="<?php echo e(route('translator.create')); ?>" class="btn btn-primary shadow-md mr-2 mb-4">Add New Translator</a>
   
  
</div>
<!-- BEGIN: Data List -->
<div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
    <table class="table table-report -mt-4">
        <thead>
            <tr>
                <th class="whitespace-nowrap">ID</th>
                <th class="whitespace-nowrap">NAME</th>
                <th class="whitespace-nowrap">EMAIL</th>
                <th class="text-center whitespace-nowrap">ACTION</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $translators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <tr class="intro-x">
                <td>
                   <h4 class"font-medium whitespace-nowrap"><?php echo e($translator->id); ?></h4>
                </td>
                <td>
                    <h4 class"font-medium whitespace-nowrap"><?php echo e($translator->name); ?></h4>
                </td>
                <td >
                    <h4 class"font-medium whitespace-nowrap"><?php echo e($translator->email); ?></h4>
                </td>
                <td class="table-report__action w-56">
                    <div class="flex justify-center items-center">
                        <a class="flex items-center mr-3" href="<?php echo e(route('translator.edit', $translator->id)); ?>"> <i data-lucide="check-square" class="w-4 h-4 mr-1"></i> Edit </a>
                        <form action="<?php echo e(route('translator.destroy', $translator->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="flex items-center text-danger" type="submit" data-tw-toggle="modal" data-tw-target="#delete-confirmation-modal"> <i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Delete </button>
                        </form>
                    </div>
                </td>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<!-- END: Data List -->
<!-- END: Pagination -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\translation\resources\views/admin/managetrans.blade.php ENDPATH**/ ?>