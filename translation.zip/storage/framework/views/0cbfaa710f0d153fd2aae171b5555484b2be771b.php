

<?php $__env->startSection('content'); ?>
<div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-4 mb-4">   
  
</div>

<div class="intro-y flex items-center h-10 mb-5 mt-2">
    <h2 class="text-lg font-medium truncate ml-2 mr-5">
        Pending Orders
    </h2>
</div>
<hr style="margin-bottom: 30px;">
<!-- BEGIN: Data List -->
<div class="intro-y box">
    <div id="vertical-form" class="p-5">
        <div class="preview">
            <div>
              <div class="overflow-x-auto">
                    <table id="myTable" class="table table-striped" style="width:100%">                      
        <thead>
              <tr>
                  <th class="whitespace-nowrap">Work Number</th>
                  <th class="whitespace-nowrap">Current Language</th>
                  <th class="whitespace-nowrap">Translated Language</th>
                  <th class="whitespace-nowrap">Payment Status</th>
                  <th class="whitespace-nowrap">Order Status</th>
                  <th class="whitespace-nowrap">Actions</th>
                  <th class="whitespace-nowrap">Next Step</th>

              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
                  <td class="whitespace-nowrap"><?php echo e($order->worknumber); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->language1); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($order->language2); ?></td>
                  <?php if($order->paymentStatus == 1): ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-success w-24 mr-1 mb-2">Paid</button></td>
                  <?php else: ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-pending w-24 mr-1 mb-2">Pending</button></td>
                  <?php endif; ?>
                  <td class="whitespace-nowrap">
                    <?php if($order->invoiceSent == 0): ?>
                    <div class="progress h-6">
                        <div class="progress-bar w-1/4" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                    </div>
                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 0 && $order->is_evidence == 1): ?>
                    <div class="progress h-6">
                        <div class="progress-bar w-1/4" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">30%</div>
                    </div>
                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 0): ?>
                    <div class="progress h-6">
                        <div class="progress-bar w-1/4" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">25%</div>
                    </div>
                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 1 && $order->translation_status == 0): ?>
                    <div class="progress h-6">
                        <div class="progress-bar w-2/4" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">50%</div>
                    </div>
                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 1 && $order->translation_status == 1 && $order->proofread_status == 0): ?>
                    <div class="progress h-6">
                        <div class="progress-bar w-3/4" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">75%</div>
                    </div>
                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 1 && $order->translation_status == 1 && $order->proofread_status == 1): ?>
                    <div class="progress h-6">
                        <div class="progress-bar w-4/4" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">100%</div>
                    </div>
                    <?php endif; ?>

                  </td>
                  
                  
                  <td class="whitespace-nowrap">
                    <div class="flex  items-center">
                        

                        <a href="<?php echo e(route('downloadFiles',$order->id)); ?>" class="btn btn-warning mr-1 mb-2"> <i data-lucide="download" class="w-5 h-5"></i> </a>
                        
                        <form action="<?php echo e(route('destroy', $order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div> <button type="submit" class="btn btn-danger mb-2"><i data-lucide="trash" class="w-4 h-4"></i></button> </div> <!-- END: Modal Toggle -->
                        </form>

                    </div>  
                </td>

                <td class="whitespace-nowrap">
                    <?php if($order->invoiceSent == 0): ?>
                    <a href="<?php echo e(route('invoice.customInvoice',$order->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="calendar" class="w-5 h-5 mr-2"></i> Send Invoice</a>

                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 0 && $order->is_evidence == 1): ?>
                    <a href="<?php echo e(route('downloadEvidence',$order->id)); ?>" class="btn btn-warning mr-1 mb-2"> <i data-lucide="mouse-pointer" class="w-5 h-5 mr-2"></i> Download Proof</a>
                    <a href="<?php echo e(route('approveEvidence',$order->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="thumbs-up" class="w-5 h-5"></i></a>
                    <a href="<?php echo e(route('rejectEvidence',$order->id)); ?>" class="btn btn-danger mr-1 mb-2"> <i data-lucide="thumbs-down" class="w-5 h-5"></i></a>


                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 0): ?>
                    <button class="btn btn-warning mr-1 mb-2"> Waiting for Payment <i data-loading-icon="three-dots" data-color="1a202c" class="w-4 h-4 ml-2"></i> </button>

                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 1 && $order->translation_status == 0): ?>
                    <a href="<?php echo e(route('mailToTranslator',$order->id)); ?>" class="btn btn-pending mr-1 mb-2"> <i data-lucide="mail" class="w-5 h-5 mr-2"></i> Mail to Translator </a>

                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 1 && $order->translation_status == 1 && $order->proofread_status == 0): ?>
                    <a href="<?php echo e(route('mailToProofReader',$order->id)); ?>" class="btn btn-dark mr-1 mb-2"><i data-lucide="mail" class="w-5 h-5 mr-2"></i> Mail to Proofreader </a>

                    <?php elseif($order->invoiceSent == 1 && $order->paymentStatus == 1 && $order->translation_status == 1 && $order->proofread_status == 1): ?>
                    <a href="<?php echo e(route('mailOfCompletion',$order->id)); ?>" class="btn btn-success mr-1 mb-2"><i data-lucide="mail" class="w-5 h-5 mr-2"></i> Send Translation to User </a>

                    <?php endif; ?>

                  </td>


              </tr>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


    </div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translation\resources\views/admin/pendingOrders.blade.php ENDPATH**/ ?>