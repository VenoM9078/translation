<?php $__env->startComponent('mail::message'); ?>
# Hello, <?php echo e($user->name); ?>!

Your translation order has been placed!
An invoice will be sent to you shortly!<br>

Your assigned worknumber is <bold><span style="color: #000;"><?php echo e($order->worknumber); ?></span></bold>

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
View Orders
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\translation\resources\views/emails/orderCreated.blade.php ENDPATH**/ ?>