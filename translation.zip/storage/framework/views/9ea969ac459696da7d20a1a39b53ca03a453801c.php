

<?php $__env->startSection('content'); ?>
<div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-4 mb-4">   
  
</div>
<div class="intro-y flex items-center h-10 mb-5 mt-2">
    <h2 class="text-lg font-medium truncate ml-2 mr-5">
        Invoices
    </h2>
</div>
<hr>
<!-- BEGIN: Data List -->

<?php if($message = Session::get('message')): ?>
        <div class="alert alert-success mt-3 mb-3">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="intro-y box">
        <div id="vertical-form" class="p-5">
            <div class="preview">
                <div>
                  <div class="overflow-x-auto">
                        <table id="myTable" class="table table-striped" style="width:100%">                        
        <thead>
              <tr>
                  <th class="whitespace-nowrap">Order Worknumber</th>
                  <th class="whitespace-nowrap">User Email</th>
                  <th class="whitespace-nowrap">Payment Status</th>
                  <th class="whitespace-nowrap">Amount</th>
                  <th class="whitespace-nowrap">Actions</th>

              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <tr>
                  <td class="whitespace-nowrap"><?php echo e($invoice->order->worknumber); ?></td>
                  <td class="whitespace-nowrap"><?php echo e($invoice->order->user->email); ?></td>
                  <?php if($invoice->order->paymentStatus == 1): ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-success w-24 mr-1 mb-2">Paid</button></td>
                  <?php else: ?>
                  <td class="whitespace-nowrap"><button class="btn btn-rounded-pending w-24 mr-1 mb-2">Pending</button></td>
                  <?php endif; ?>                  
                  <td class="whitespace-nowrap">$<?php echo e($invoice->amount); ?></td>
                  
                  
                  
                  <td class="whitespace-nowrap">
                    <div class="flex  items-center">
                        

                        <form action="<?php echo e(route('invoice.destroy', $invoice->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <div> <button type="submit" class="btn btn-danger mb-2"><i data-lucide="trash" class="w-4 h-4"></i></button> </div> <!-- END: Modal Toggle -->
                        </form>

                    </div>  
                </td>


              </tr>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>


                  </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translation\resources\views/admin/invoices.blade.php ENDPATH**/ ?>