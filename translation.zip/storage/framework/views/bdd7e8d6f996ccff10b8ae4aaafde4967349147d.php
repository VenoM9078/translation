

<?php $__env->startSection('content'); ?>
<div class="intro-y col-span-12 mt-4">
    <!-- BEGIN: Vertical Form -->
    <div class="intro-y box">
        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-slate-200/60 dark:border-darkmode-400">
            <h2 class="font-medium text-base mr-auto">
               Add Invoice for <?php echo e($order->user->name); ?>'s Translation Order
            </h2>
            
        </div>
        <div id="vertical-form" class="p-5">
            <form action="<?php echo e(route('invoice.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
            <div class="preview">
                <div>
                    <div class="intro-x mt-4">
                        <input type="hidden" name="user_id" value="<?php echo e($order->user->id); ?>">
                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                        <input type="text" name="description" class="intro-x login__input form-control py-3 px-4 block" placeholder="Enter Translation Description">
                        <input type="number" name="docQuantity" class="intro-x login__input form-control py-3 px-4 block mt-4" placeholder="Enter Number of Pages to be Translated">
                        <input type="number" name="amount" class="intro-x login__input form-control py-3 px-4 block mt-4" placeholder="Enter Amount to be charged (in dollars)">
                        
                        
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-5">Send Invoice to <?php echo e($order->user->name); ?></button>
            </div>
        </form>
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\translation\resources\views/admin/createInvoice.blade.php ENDPATH**/ ?>